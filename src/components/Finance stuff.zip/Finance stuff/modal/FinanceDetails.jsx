import React, { useEffect, useState } from "react";
import TagInputs from "../../layouts/TagInputs";
import axios from "axios";
import { usePatient } from "../../../contexts";
import { RiCloseFill } from "react-icons/ri";
import Spinner from "../../UI/Spinner";
import PaymentHistory from "../../tables/Patient_Payment_History";

function FinanceDetails({ closeModal }) {
  const [paymentHistory, setPaymentHistory] = useState(false);
  const [hmo, setHmo] = useState([]);
  const { patientId, patientName, patientPage, hmoId } = usePatient();
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false);

  const handlePageChange = (newPage) => {
    if (newPage > 0 && newPage <= totalPages) {
      setCurrentPage(newPage);
    }
  };

  const generatePageNumbers = () => {
    let pages = [];
    if (totalPages <= 5) {
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i);
      }
    } else {
      if (currentPage <= 3) {
        pages = [1, 2, 3, 4, totalPages];
      } else if (currentPage >= totalPages - 2) {
        pages = [1, totalPages - 3, totalPages - 2, totalPages - 1, totalPages];
      } else {
        pages = [1, currentPage - 1, currentPage, currentPage + 1, totalPages];
      }
    }
    return pages;
  };

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth <= 768);
    window.addEventListener('resize', handleResize);
    getHmo();
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    getPaymentHistory()
  },[currentPage])

  const getPaymentHistory = async () => {
    setLoading(true)
    const token = sessionStorage.getItem('token');

    if (!token) {
      console.error('Token not found in session storage');
      return;
    }

    const options = {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    };

    try {
      const response = await axios.get(`https://edogoverp.com/healthfinanceapi/api/patientpayment/list/patient/${patientId}/${currentPage}/10/patient-payment-history`, options);
      console.log(response);
      setPaymentHistory(response?.data?.resultList);
      setTotalPages(response?.data?.totalPages);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching payment history:", error);
      setLoading(false)
    }
  };

  const getHmo = async () => {
    const token = sessionStorage.getItem('token');

    if (!token) {
      console.error('Token not found in session storage');
      return;
    }

    const options = {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    };

    try {
      const response = await axios.get(`https://edogoverp.com/healthfinanceapi/api/hmo/${hmoId}`, options);
      console.log(response);
      setHmo(response?.data);
    } catch (error) {
      console.error("Error fetching HMO:", error);
    }
  };


  const headerStyle = {
    marginTop: "20px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    flexWrap: isMobile ? "wrap" : "nowrap",
  };

  const patientInfoStyle = {
    display: "flex",
    alignItems: "center",
    alignContent: "center",
    flexDirection: "column",

  };

  const patientDetailsStyle = {
    marginBottom: "10px",
  };

  const hmoDetailsStyle = {
    display: "flex",
    marginTop: "10px",

    justifyContent: "space-between",
    flexDirection: "column",
    flexWrap: isMobile ? "wrap" : "nowrap",
  };

  const hmoItemStyle = {
    flex: isMobile ? "1 1 100%" : "1 1 45%",
    margin: "10px 0",
  };

  const historicalPaymentsStyle = {
    marginTop: "20px",
  };

  return (
    <div className="overlay" >
      <RiCloseFill className='close-btn pointer' onClick={() => closeModal(false)} />
      <div className="modal-contents p-20">
        <>
          {loading ? <Spinner /> :
            <>
              <div style={headerStyle}>
                <div style={patientInfoStyle}>
                  <h2 style={patientDetailsStyle}>{patientName}</h2>
                </div>

              </div>
              <div style={hmoDetailsStyle}>
                <>
                  {hmo?.vendorName &&
                    <div className="col-5">
                      <TagInputs
                        className="no-wrap"
                        value={`${hmo?.vendorName || ''}  |  ${hmo?.taxIdentityNumber || ''}`}
                        disabled
                        label="HMO Provider"
                      />
                    </div>
                  }
                </>
              </div>
              <h3 className="m-b-10">Payment History</h3>
              <div>
                <PaymentHistory data={paymentHistory} />
                <div className="pagination flex space-between flex-v-center col-3 m-t-20">
                  <div className="flex gap-8">
                    <div className="bold-text">Page</div> <div className="m-r-10">{currentPage}/{totalPages}</div>
                  </div>
                  <div className="flex gap-8">
                    <button
                      className={`pagination-btn ${currentPage === 1 ? 'disabled' : ''}`}
                      onClick={() => handlePageChange(currentPage - 1)}
                      disabled={currentPage === 1}
                    >
                      {"Previous"}
                    </button>

                    {generatePageNumbers().map((page, index) => (
                      <button
                        key={`page-${index}`}
                        className={`pagination-btn ${currentPage === page ? 'bg-green text-white' : ''}`}
                        onClick={() => handlePageChange(page)}
                      >
                        {page}
                      </button>
                    ))}

                    <button
                      className={`pagination-btn ${currentPage === totalPages ? 'disabled' : ''}`}
                      onClick={() => handlePageChange(currentPage + 1)}
                      disabled={currentPage === totalPages}
                    >
                      {"Next"}
                    </button>
                  </div>
                </div>
              </div>

            </>
          }
        </>
      </div>
    </div>
  );
}

export default FinanceDetails;
